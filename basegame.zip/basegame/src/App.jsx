import { BrowserRouter, Link } from 'react-router-dom';

import './App.css'
import BoardGame from './BoardGame';
// import AppRoutes from './routes/AppRoutes';
// import Links from './routes/Links'
// import BoardGame from './BoardGame';
// import Card from './Card'


function App() {
  return (
  //  <Card/> 
  <BoardGame/>
  )


}

export default App


{/* <BrowserRouter>
      <>
        <Links />
        <AppRoutes />
      </>
    </BrowserRouter> */}