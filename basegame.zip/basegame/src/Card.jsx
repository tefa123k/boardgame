import React from 'react'

const Card = ({ res }) => {
    return (
        <div style={{
            backgroundImage: `url(${res.img})`, order: res.order
        }} className={`cell ${(res.status == 'open') ? 'open' : ""} ${(res.status == 'win') ? "win" : ""} ${(res.status == "close") ? "close" : ""}`} key={index} onClick={(event) => handleClick(event, index)}>
            <span className='content'>

            </span>
        </div>
    )
}

export default Card