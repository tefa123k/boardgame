# React BaseGame  
Es un juego de memorización que permitira trabajar con algunos Hooks como: useState, useRoutes, useEffect, useRef para crear un juego multiple de memoria
Autor @darwinyusef

- ![react js](https://raw.githubusercontent.com/darwinyusef/reactjs-basegame/master/public/img/react.jpg)
- ![js](https://raw.githubusercontent.com/darwinyusef/reactjs-basegame/master/public/img/js.jpg)

Aceptación de uso con atribución de uso académico no comercial
- Legal atributtion [CC BY-NC-SA 2.5 CO CÓDIGO LEGAL](https://creativecommons.org/licenses/by-nc-sa/2.5/co/legalcode.es)
- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) 
